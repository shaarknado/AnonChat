import {
  FREIGHTER_ID,
  ALBEDO_ID,
  StellarWalletsKit,
  WalletNetwork,
  FreighterModule,
  AlbedoModule,
  RabetModule,
  LobstrModule,
  HanaModule,
} from "@creit.tech/stellar-wallets-kit";

export type DetectedNetwork = "testnet" | "mainnet" | "unknown";

export { FREIGHTER_ID, ALBEDO_ID };

const SELECTED_WALLET_ID = "selectedWalletId";
const WALLET_CONNECTED = "walletConnected";
const disconnectListeners: Set<() => void> = new Set();

function getSelectedWalletId() {
  if (typeof window === "undefined") return null;
  return localStorage.getItem(SELECTED_WALLET_ID);
}

function isWalletConnected() {
  if (typeof window === "undefined") return false;
  return localStorage.getItem(WALLET_CONNECTED) === "true";
}

function clearWalletStorage() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(SELECTED_WALLET_ID);
  localStorage.removeItem(WALLET_CONNECTED);
}

let kit: StellarWalletsKit | null = null;

function getExpectedWalletNetwork(): WalletNetwork {
  if (typeof process !== "undefined" && process.env.NEXT_PUBLIC_STELLAR_NETWORK) {
    const env = process.env.NEXT_PUBLIC_STELLAR_NETWORK.toLowerCase();
    if (env === "testnet") return WalletNetwork.TESTNET;
  }
  return WalletNetwork.PUBLIC;
}

function getKit(): StellarWalletsKit | null {
  if (typeof window === "undefined") return null;
  if (kit) return kit;

  try {
    kit = new StellarWalletsKit({
      modules: [
        new FreighterModule(),
        new AlbedoModule(),
        new RabetModule(),
        new LobstrModule(),
        new HanaModule(),
      ],
      network: getExpectedWalletNetwork(),
      selectedWalletId: getSelectedWalletId() ?? FREIGHTER_ID,
    });
  } catch (e) {
    console.error("Failed to initialize StellarWalletsKit:", e);
    return null;
  }

  return kit;
}

export function getExpectedNetwork(): DetectedNetwork {
  const network = getExpectedWalletNetwork();
  if (network === WalletNetwork.TESTNET) return "testnet";
  return "mainnet";
}

export async function detectWalletNetwork(): Promise<DetectedNetwork> {
  if (typeof window === "undefined") return "unknown";

  const walletId = getSelectedWalletId();
  if (!walletId) return "unknown";

  try {
    if (walletId === FREIGHTER_ID) {
      const module = new FreighterModule();
      const isAvailable = await module.isAvailable();
      if (!isAvailable) return "unknown";
      const { network } = await module.getNetwork();
      const upper = network.toUpperCase();
      if (upper === "PUBLIC") return "mainnet";
      if (upper === "TESTNET" || upper === "TEST") return "testnet";
      if (network.includes("Test SDF Network")) return "testnet";
      if (network.includes("Public Global")) return "mainnet";
      return "unknown";
    }

    if (walletId === ALBEDO_ID) {
      const module = new AlbedoModule();
      const isAvailable = await module.isAvailable();
      if (!isAvailable) return "unknown";
      const { network } = await module.getNetwork();
      const upper = network.toUpperCase();
      if (upper === "PUBLIC") return "mainnet";
      if (upper === "TESTNET" || upper === "TEST") return "testnet";
      return "unknown";
    }
  } catch (e) {
    console.error("Failed to detect wallet network:", e);
  }

  return "unknown";
}

export async function signTransaction(...args: any[]) {
  const kitInstance = getKit();
  if (!kitInstance) return null;
  // @ts-ignore
  return kitInstance.signTransaction(...args);
}

export async function signMessage(message: string): Promise<string> {
  const kitInstance = getKit();
  if (!kitInstance) return "";

  const { signedMessage } = await kitInstance.signMessage(message);

  // signedMessage is base64 string → convert to hex
  const decoded = Uint8Array.from(atob(signedMessage), (c) => c.charCodeAt(0));

  return Array.from(decoded)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

export async function getPublicKey() {
  if (typeof window === "undefined") return null;
  if (!getSelectedWalletId() || !isWalletConnected()) return null;

  const kitInstance = getKit();
  if (!kitInstance) return null;

  try {
    const { address } = await kitInstance.getAddress();
    return address;
  } catch (e) {
    console.error("Failed to get public key:", e);
    return null;
  }
}

export async function autoReconnect() {
  if (!isWalletConnected() || !getSelectedWalletId()) return null;

  try {
    return await getPublicKey();
  } catch {
    clearWalletStorage();
    return null;
  }
}

export async function setWallet(walletId: string) {
  if (typeof window !== "undefined") {
    localStorage.setItem(SELECTED_WALLET_ID, walletId);
    localStorage.setItem(WALLET_CONNECTED, "true");

    const kitInstance = getKit();
    if (!kitInstance) return;

    kitInstance.setWallet(walletId);
  }
}

export function onDisconnect(callback: () => void) {
  disconnectListeners.add(callback);
  return () => {
    disconnectListeners.delete(callback);
  };
}

export async function disconnect(callback?: () => Promise<void>) {
  if (typeof window !== "undefined") {
    clearWalletStorage();

    const kitInstance = getKit();
    if (!kitInstance) return;

    kitInstance.disconnect();

    disconnectListeners.forEach((listener) => listener());

    if (callback) await callback();
  }
}

export async function connect(callback?: () => Promise<void>) {
  if (typeof window === "undefined") return;

  const kitInstance = getKit();
  if (!kitInstance) return;

  await kitInstance.openModal({
    onWalletSelected: async (option: any) => {
      try {
        await setWallet(option.id);
        if (callback) await callback();
      } catch (e) {
        console.error(e);
      }

      return option.id;
    },
  });
}

/**
 * Connects directly to a specific wallet without opening the kit's modal.
 */
export async function connectToWallet(walletId: string, callback?: () => Promise<void>) {
  if (typeof window === "undefined") return;

  const kitInstance = getKit();
  if (!kitInstance) return;

  try {
    // Check if wallet is available
    if (walletId === FREIGHTER_ID) {
      const freighter = new FreighterModule();
      const isAvailable = await freighter.isAvailable();
      if (!isAvailable) {
        throw new Error("Freighter extension is not installed or enabled.");
      }
    }

    await setWallet(walletId);
    if (callback) await callback();
  } catch (e: any) {
    console.error(`Failed to connect to wallet ${walletId}:`, e);
    throw e;
  }
}

